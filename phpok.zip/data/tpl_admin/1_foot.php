<?php if(!defined("PHPOK_SET")){exit("<h1>Access Denied</h1>");} ?>		<br />
		<?php echo $GLOBALS["app"]->plugin_html_ap("body");?>
	</div>
	<div class="clear"></div>
</div>
<div class="foot" style="text-align:center;"></div>
<?php echo $GLOBALS["app"]->plugin_html_ap("foot");?>
<?php echo $app->plugin_html_ap("phpokbody");?></body>
</html>