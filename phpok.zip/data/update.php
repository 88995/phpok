<?php

$uconfig["status"] = "1";
$uconfig["server"] = "http://update.phpok.com/";
$uconfig["date"] = "5";
$uconfig["ip"] = "127.0.0.1";

?>